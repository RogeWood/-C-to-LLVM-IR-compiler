// Generated from Cactus.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class CactusParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		AND=1, BEGIN=2, DO=3, ELSE=4, END=5, ENDIF=6, ENDWHILE=7, EXIT=8, IF=9, 
		SET=10, NOT=11, OR=12, PROGRAM=13, READ=14, THEN=15, VAR=16, WHILE=17, 
		WRITE=18, ID=19, INT=20, WS=21, COMMENT=22, ADD=23, NEG=24, MUL=25, DIV=26, 
		MOD=27, ASSIGN=28, EQUAL=29, NOTEQUAL=30, GREATER=31, GREATEREQUAL=32, 
		LESS=33, LESSEQUAL=34, LPAREN=35, RPAREN=36;
	public static final int
		RULE_program = 0, RULE_declarations = 1, RULE_declaration = 2, RULE_statements = 3, 
		RULE_statement = 4, RULE_readStmt = 5, RULE_writeStmt = 6, RULE_exitStmt = 7, 
		RULE_assignStmt = 8, RULE_expr = 9, RULE_multExpr = 10, RULE_primaryExpr = 11, 
		RULE_token = 12;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "declarations", "declaration", "statements", "statement", 
			"readStmt", "writeStmt", "exitStmt", "assignStmt", "expr", "multExpr", 
			"primaryExpr", "token"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'And'", "'Begin'", "'Do'", "'Else'", "'End'", "'EndIf'", "'EndWhile'", 
			"'Exit'", "'If'", "'Set'", "'Not'", "'Or'", "'Program'", "'Read'", "'Then'", 
			"'Var'", "'While'", "'Write'", null, null, null, null, "'+'", "'-'", 
			"'*'", "'/'", "'%'", "'='", "'=='", "'<>'", "'>'", "'>='", "'<'", "'<='", 
			"'('", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "AND", "BEGIN", "DO", "ELSE", "END", "ENDIF", "ENDWHILE", "EXIT", 
			"IF", "SET", "NOT", "OR", "PROGRAM", "READ", "THEN", "VAR", "WHILE", 
			"WRITE", "ID", "INT", "WS", "COMMENT", "ADD", "NEG", "MUL", "DIV", "MOD", 
			"ASSIGN", "EQUAL", "NOTEQUAL", "GREATER", "GREATEREQUAL", "LESS", "LESSEQUAL", 
			"LPAREN", "RPAREN"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Cactus.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }


	    int tempCounter = 0;

	    String newTemp() {
	        return "$t" + (tempCounter++);
	    }

	    String CurrTemp() {
	        return "$t" + (tempCounter);
	    }

	    void releaseTemp() {
	        tempCounter--;
	    }

	    String insertBeforeFirstNewline(String original, String toInsert) {
	        int newlineIndex = original.indexOf('\n');
	        
	        if (newlineIndex == -1) {
	            return original + toInsert;
	        }
	        
	        return original.substring(0, newlineIndex) + toInsert + original.substring(newlineIndex);
	    }

	public CactusParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgramContext extends ParserRuleContext {
		public TerminalNode PROGRAM() { return getToken(CactusParser.PROGRAM, 0); }
		public TerminalNode BEGIN() { return getToken(CactusParser.BEGIN, 0); }
		public DeclarationsContext declarations() {
			return getRuleContext(DeclarationsContext.class,0);
		}
		public StatementsContext statements() {
			return getRuleContext(StatementsContext.class,0);
		}
		public TerminalNode END() { return getToken(CactusParser.END, 0); }
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitProgram(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(26);
			match(PROGRAM);
			setState(27);
			match(BEGIN);
			 System.out.println("\t.data"); 
			setState(29);
			declarations();
			 System.out.println("\t.text\nmain:"); 
			setState(31);
			statements();
			setState(32);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DeclarationsContext extends ParserRuleContext {
		public List<DeclarationContext> declaration() {
			return getRuleContexts(DeclarationContext.class);
		}
		public DeclarationContext declaration(int i) {
			return getRuleContext(DeclarationContext.class,i);
		}
		public DeclarationsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declarations; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterDeclarations(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitDeclarations(this);
		}
	}

	public final DeclarationsContext declarations() throws RecognitionException {
		DeclarationsContext _localctx = new DeclarationsContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_declarations);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(37);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==VAR) {
				{
				{
				setState(34);
				declaration();
				}
				}
				setState(39);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DeclarationContext extends ParserRuleContext {
		public Token ID;
		public TerminalNode VAR() { return getToken(CactusParser.VAR, 0); }
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public DeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitDeclaration(this);
		}
	}

	public final DeclarationContext declaration() throws RecognitionException {
		DeclarationContext _localctx = new DeclarationContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_declaration);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(40);
			match(VAR);
			setState(41);
			((DeclarationContext)_localctx).ID = match(ID);
			 
			            System.out.println((((DeclarationContext)_localctx).ID!=null?((DeclarationContext)_localctx).ID.getText():null) + ": \t\t\t\t# Var " + (((DeclarationContext)_localctx).ID!=null?((DeclarationContext)_localctx).ID.getText():null)); 
			            System.out.println("\t.word 0");
			        
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StatementsContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public StatementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterStatements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitStatements(this);
		}
	}

	public final StatementsContext statements() throws RecognitionException {
		StatementsContext _localctx = new StatementsContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_statements);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(47);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 279808L) != 0)) {
				{
				{
				setState(44);
				statement();
				}
				}
				setState(49);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StatementContext extends ParserRuleContext {
		public ReadStmtContext readStmt() {
			return getRuleContext(ReadStmtContext.class,0);
		}
		public WriteStmtContext writeStmt() {
			return getRuleContext(WriteStmtContext.class,0);
		}
		public ExitStmtContext exitStmt() {
			return getRuleContext(ExitStmtContext.class,0);
		}
		public AssignStmtContext assignStmt() {
			return getRuleContext(AssignStmtContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterStatement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitStatement(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_statement);
		try {
			setState(54);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case READ:
				enterOuterAlt(_localctx, 1);
				{
				setState(50);
				readStmt();
				}
				break;
			case WRITE:
				enterOuterAlt(_localctx, 2);
				{
				setState(51);
				writeStmt();
				}
				break;
			case EXIT:
				enterOuterAlt(_localctx, 3);
				{
				setState(52);
				exitStmt();
				}
				break;
			case SET:
				enterOuterAlt(_localctx, 4);
				{
				setState(53);
				assignStmt();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ReadStmtContext extends ParserRuleContext {
		public Token ID;
		public TerminalNode READ() { return getToken(CactusParser.READ, 0); }
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public ReadStmtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_readStmt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterReadStmt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitReadStmt(this);
		}
	}

	public final ReadStmtContext readStmt() throws RecognitionException {
		ReadStmtContext _localctx = new ReadStmtContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_readStmt);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(56);
			match(READ);
			setState(57);
			((ReadStmtContext)_localctx).ID = match(ID);

			            String temp = newTemp();
			            System.out.println("\tli $v0, 5" + "\t\t\t\t# Read " + (((ReadStmtContext)_localctx).ID!=null?((ReadStmtContext)_localctx).ID.getText():null));
			            System.out.println("\tsyscall");
			            System.out.println("\tla " + temp + ", " + (((ReadStmtContext)_localctx).ID!=null?((ReadStmtContext)_localctx).ID.getText():null));
			            System.out.println("\tsw $v0, 0(" + temp + ")");
			            releaseTemp();
			        
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WriteStmtContext extends ParserRuleContext {
		public ExprContext expr;
		public TerminalNode WRITE() { return getToken(CactusParser.WRITE, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public WriteStmtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_writeStmt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterWriteStmt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitWriteStmt(this);
		}
	}

	public final WriteStmtContext writeStmt() throws RecognitionException {
		WriteStmtContext _localctx = new WriteStmtContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_writeStmt);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			match(WRITE);
			setState(61);
			((WriteStmtContext)_localctx).expr = expr();

			            
			            String instruction = "\t\t\t\t# Write " + (((WriteStmtContext)_localctx).expr!=null?_input.getText(((WriteStmtContext)_localctx).expr.start,((WriteStmtContext)_localctx).expr.stop):null);
			            System.out.print(insertBeforeFirstNewline(((WriteStmtContext)_localctx).expr.code, instruction));
			            System.out.println("\tmove $a0, " + ((WriteStmtContext)_localctx).expr.result);
			            System.out.println("\tli $v0, 1");
			            System.out.println("\tsyscall");
			        
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExitStmtContext extends ParserRuleContext {
		public TerminalNode EXIT() { return getToken(CactusParser.EXIT, 0); }
		public ExitStmtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exitStmt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterExitStmt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitExitStmt(this);
		}
	}

	public final ExitStmtContext exitStmt() throws RecognitionException {
		ExitStmtContext _localctx = new ExitStmtContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_exitStmt);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(64);
			match(EXIT);

			            System.out.println("\tli $v0, 10" + ": \t\t\t\t# Exit");
			            System.out.println("\tsyscall");
			        
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AssignStmtContext extends ParserRuleContext {
		public Token ID;
		public ExprContext expr;
		public TerminalNode SET() { return getToken(CactusParser.SET, 0); }
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public TerminalNode ASSIGN() { return getToken(CactusParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public AssignStmtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignStmt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterAssignStmt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitAssignStmt(this);
		}
	}

	public final AssignStmtContext assignStmt() throws RecognitionException {
		AssignStmtContext _localctx = new AssignStmtContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_assignStmt);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(67);
			match(SET);
			setState(68);
			((AssignStmtContext)_localctx).ID = match(ID);
			setState(69);
			match(ASSIGN);
			setState(70);
			((AssignStmtContext)_localctx).expr = expr();

			            String instruction = "\t\t\t\t# SET " + (((AssignStmtContext)_localctx).ID!=null?((AssignStmtContext)_localctx).ID.getText():null) + " = " + (((AssignStmtContext)_localctx).expr!=null?_input.getText(((AssignStmtContext)_localctx).expr.start,((AssignStmtContext)_localctx).expr.stop):null);

			            releaseTemp();
			            String temp = CurrTemp();
			            System.out.print(insertBeforeFirstNewline(((AssignStmtContext)_localctx).expr.code, instruction));
			            System.out.println("\tla " + temp + ", " + (((AssignStmtContext)_localctx).ID!=null?((AssignStmtContext)_localctx).ID.getText():null));
			            System.out.println("\tsw " + ((AssignStmtContext)_localctx).expr.result + ", 0(" + temp+ ")");
			            releaseTemp();
			        
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public String code;
		public String result;
		public MultExprContext e1;
		public MultExprContext e2;
		public List<MultExprContext> multExpr() {
			return getRuleContexts(MultExprContext.class);
		}
		public MultExprContext multExpr(int i) {
			return getRuleContext(MultExprContext.class,i);
		}
		public List<TerminalNode> ADD() { return getTokens(CactusParser.ADD); }
		public TerminalNode ADD(int i) {
			return getToken(CactusParser.ADD, i);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitExpr(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_expr);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			((ExprContext)_localctx).e1 = multExpr();
			 ((ExprContext)_localctx).code =  ((ExprContext)_localctx).e1.code; ((ExprContext)_localctx).result =  ((ExprContext)_localctx).e1.result; 
			setState(81);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ADD) {
				{
				{
				setState(75);
				match(ADD);
				setState(76);
				((ExprContext)_localctx).e2 = multExpr();
				 
				            ((ExprContext)_localctx).code =  _localctx.code + ((ExprContext)_localctx).e2.code + "\tadd " + _localctx.result + ", " + _localctx.result + ", " + ((ExprContext)_localctx).e2.result + "\n";
				        
				}
				}
				setState(83);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MultExprContext extends ParserRuleContext {
		public String code;
		public String result;
		public PrimaryExprContext e1;
		public PrimaryExprContext e2;
		public List<PrimaryExprContext> primaryExpr() {
			return getRuleContexts(PrimaryExprContext.class);
		}
		public PrimaryExprContext primaryExpr(int i) {
			return getRuleContext(PrimaryExprContext.class,i);
		}
		public List<TerminalNode> MUL() { return getTokens(CactusParser.MUL); }
		public TerminalNode MUL(int i) {
			return getToken(CactusParser.MUL, i);
		}
		public MultExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multExpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterMultExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitMultExpr(this);
		}
	}

	public final MultExprContext multExpr() throws RecognitionException {
		MultExprContext _localctx = new MultExprContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_multExpr);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(84);
			((MultExprContext)_localctx).e1 = primaryExpr();
			 ((MultExprContext)_localctx).code =  ((MultExprContext)_localctx).e1.code; ((MultExprContext)_localctx).result =  ((MultExprContext)_localctx).e1.result; 
			setState(92);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==MUL) {
				{
				{
				setState(86);
				match(MUL);
				setState(87);
				((MultExprContext)_localctx).e2 = primaryExpr();
				 
				            ((MultExprContext)_localctx).code =  _localctx.code + ((MultExprContext)_localctx).e2.code + "\tmul " + _localctx.result + ", " + _localctx.result + ", " + ((MultExprContext)_localctx).e2.result + "\n";
				        
				}
				}
				setState(94);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PrimaryExprContext extends ParserRuleContext {
		public String code;
		public String result;
		public Token ID;
		public Token INT;
		public PrimaryExprContext primaryExpr;
		public ExprContext expr;
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public TerminalNode INT() { return getToken(CactusParser.INT, 0); }
		public TerminalNode NEG() { return getToken(CactusParser.NEG, 0); }
		public PrimaryExprContext primaryExpr() {
			return getRuleContext(PrimaryExprContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(CactusParser.LPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(CactusParser.RPAREN, 0); }
		public PrimaryExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_primaryExpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterPrimaryExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitPrimaryExpr(this);
		}
	}

	public final PrimaryExprContext primaryExpr() throws RecognitionException {
		PrimaryExprContext _localctx = new PrimaryExprContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_primaryExpr);
		try {
			setState(108);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(95);
				((PrimaryExprContext)_localctx).ID = match(ID);

				            String temp = newTemp();
				            ((PrimaryExprContext)_localctx).code =  "\tla " + temp + ", " + (((PrimaryExprContext)_localctx).ID!=null?((PrimaryExprContext)_localctx).ID.getText():null) + "\n\tlw " + temp + ", 0(" + temp + ")\n";
				            ((PrimaryExprContext)_localctx).result =  temp;
				        
				}
				break;
			case INT:
				enterOuterAlt(_localctx, 2);
				{
				setState(97);
				((PrimaryExprContext)_localctx).INT = match(INT);

				            String temp = newTemp();
				            ((PrimaryExprContext)_localctx).code =  "\tli " + temp + ", " + (((PrimaryExprContext)_localctx).INT!=null?((PrimaryExprContext)_localctx).INT.getText():null) + "\n";
				            ((PrimaryExprContext)_localctx).result =  temp;
				            releaseTemp();
				        
				}
				break;
			case NEG:
				enterOuterAlt(_localctx, 3);
				{
				setState(99);
				match(NEG);
				setState(100);
				((PrimaryExprContext)_localctx).primaryExpr = primaryExpr();

				            ((PrimaryExprContext)_localctx).code =  ((PrimaryExprContext)_localctx).primaryExpr.code + "\tneg " + ((PrimaryExprContext)_localctx).primaryExpr.result + ", " + ((PrimaryExprContext)_localctx).primaryExpr.result + "\n";
				            ((PrimaryExprContext)_localctx).result =  ((PrimaryExprContext)_localctx).primaryExpr.result;
				        
				}
				break;
			case LPAREN:
				enterOuterAlt(_localctx, 4);
				{
				setState(103);
				match(LPAREN);
				setState(104);
				((PrimaryExprContext)_localctx).expr = expr();
				setState(105);
				match(RPAREN);

				            ((PrimaryExprContext)_localctx).code =  ((PrimaryExprContext)_localctx).expr.code;
				            ((PrimaryExprContext)_localctx).result =  ((PrimaryExprContext)_localctx).expr.result;
				        
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TokenContext extends ParserRuleContext {
		public List<TerminalNode> AND() { return getTokens(CactusParser.AND); }
		public TerminalNode AND(int i) {
			return getToken(CactusParser.AND, i);
		}
		public List<TerminalNode> BEGIN() { return getTokens(CactusParser.BEGIN); }
		public TerminalNode BEGIN(int i) {
			return getToken(CactusParser.BEGIN, i);
		}
		public List<TerminalNode> DO() { return getTokens(CactusParser.DO); }
		public TerminalNode DO(int i) {
			return getToken(CactusParser.DO, i);
		}
		public List<TerminalNode> ELSE() { return getTokens(CactusParser.ELSE); }
		public TerminalNode ELSE(int i) {
			return getToken(CactusParser.ELSE, i);
		}
		public List<TerminalNode> END() { return getTokens(CactusParser.END); }
		public TerminalNode END(int i) {
			return getToken(CactusParser.END, i);
		}
		public List<TerminalNode> ENDIF() { return getTokens(CactusParser.ENDIF); }
		public TerminalNode ENDIF(int i) {
			return getToken(CactusParser.ENDIF, i);
		}
		public List<TerminalNode> ENDWHILE() { return getTokens(CactusParser.ENDWHILE); }
		public TerminalNode ENDWHILE(int i) {
			return getToken(CactusParser.ENDWHILE, i);
		}
		public List<TerminalNode> EXIT() { return getTokens(CactusParser.EXIT); }
		public TerminalNode EXIT(int i) {
			return getToken(CactusParser.EXIT, i);
		}
		public List<TerminalNode> IF() { return getTokens(CactusParser.IF); }
		public TerminalNode IF(int i) {
			return getToken(CactusParser.IF, i);
		}
		public List<TerminalNode> SET() { return getTokens(CactusParser.SET); }
		public TerminalNode SET(int i) {
			return getToken(CactusParser.SET, i);
		}
		public List<TerminalNode> NOT() { return getTokens(CactusParser.NOT); }
		public TerminalNode NOT(int i) {
			return getToken(CactusParser.NOT, i);
		}
		public List<TerminalNode> OR() { return getTokens(CactusParser.OR); }
		public TerminalNode OR(int i) {
			return getToken(CactusParser.OR, i);
		}
		public List<TerminalNode> PROGRAM() { return getTokens(CactusParser.PROGRAM); }
		public TerminalNode PROGRAM(int i) {
			return getToken(CactusParser.PROGRAM, i);
		}
		public List<TerminalNode> READ() { return getTokens(CactusParser.READ); }
		public TerminalNode READ(int i) {
			return getToken(CactusParser.READ, i);
		}
		public List<TerminalNode> THEN() { return getTokens(CactusParser.THEN); }
		public TerminalNode THEN(int i) {
			return getToken(CactusParser.THEN, i);
		}
		public List<TerminalNode> VAR() { return getTokens(CactusParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(CactusParser.VAR, i);
		}
		public List<TerminalNode> WHILE() { return getTokens(CactusParser.WHILE); }
		public TerminalNode WHILE(int i) {
			return getToken(CactusParser.WHILE, i);
		}
		public List<TerminalNode> WRITE() { return getTokens(CactusParser.WRITE); }
		public TerminalNode WRITE(int i) {
			return getToken(CactusParser.WRITE, i);
		}
		public List<TerminalNode> ID() { return getTokens(CactusParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(CactusParser.ID, i);
		}
		public List<TerminalNode> INT() { return getTokens(CactusParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(CactusParser.INT, i);
		}
		public List<TerminalNode> ADD() { return getTokens(CactusParser.ADD); }
		public TerminalNode ADD(int i) {
			return getToken(CactusParser.ADD, i);
		}
		public List<TerminalNode> NEG() { return getTokens(CactusParser.NEG); }
		public TerminalNode NEG(int i) {
			return getToken(CactusParser.NEG, i);
		}
		public List<TerminalNode> MUL() { return getTokens(CactusParser.MUL); }
		public TerminalNode MUL(int i) {
			return getToken(CactusParser.MUL, i);
		}
		public List<TerminalNode> DIV() { return getTokens(CactusParser.DIV); }
		public TerminalNode DIV(int i) {
			return getToken(CactusParser.DIV, i);
		}
		public List<TerminalNode> MOD() { return getTokens(CactusParser.MOD); }
		public TerminalNode MOD(int i) {
			return getToken(CactusParser.MOD, i);
		}
		public List<TerminalNode> ASSIGN() { return getTokens(CactusParser.ASSIGN); }
		public TerminalNode ASSIGN(int i) {
			return getToken(CactusParser.ASSIGN, i);
		}
		public List<TerminalNode> EQUAL() { return getTokens(CactusParser.EQUAL); }
		public TerminalNode EQUAL(int i) {
			return getToken(CactusParser.EQUAL, i);
		}
		public List<TerminalNode> NOTEQUAL() { return getTokens(CactusParser.NOTEQUAL); }
		public TerminalNode NOTEQUAL(int i) {
			return getToken(CactusParser.NOTEQUAL, i);
		}
		public List<TerminalNode> GREATER() { return getTokens(CactusParser.GREATER); }
		public TerminalNode GREATER(int i) {
			return getToken(CactusParser.GREATER, i);
		}
		public List<TerminalNode> GREATEREQUAL() { return getTokens(CactusParser.GREATEREQUAL); }
		public TerminalNode GREATEREQUAL(int i) {
			return getToken(CactusParser.GREATEREQUAL, i);
		}
		public List<TerminalNode> LESS() { return getTokens(CactusParser.LESS); }
		public TerminalNode LESS(int i) {
			return getToken(CactusParser.LESS, i);
		}
		public List<TerminalNode> LESSEQUAL() { return getTokens(CactusParser.LESSEQUAL); }
		public TerminalNode LESSEQUAL(int i) {
			return getToken(CactusParser.LESSEQUAL, i);
		}
		public List<TerminalNode> LPAREN() { return getTokens(CactusParser.LPAREN); }
		public TerminalNode LPAREN(int i) {
			return getToken(CactusParser.LPAREN, i);
		}
		public List<TerminalNode> RPAREN() { return getTokens(CactusParser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(CactusParser.RPAREN, i);
		}
		public List<TerminalNode> WS() { return getTokens(CactusParser.WS); }
		public TerminalNode WS(int i) {
			return getToken(CactusParser.WS, i);
		}
		public List<TerminalNode> COMMENT() { return getTokens(CactusParser.COMMENT); }
		public TerminalNode COMMENT(int i) {
			return getToken(CactusParser.COMMENT, i);
		}
		public TokenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_token; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterToken(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitToken(this);
		}
	}

	public final TokenContext token() throws RecognitionException {
		TokenContext _localctx = new TokenContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_token);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 137438953470L) != 0)) {
				{
				{
				setState(110);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 137438953470L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(115);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001$u\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002\u0002"+
		"\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002\u0005"+
		"\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002\b\u0007"+
		"\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002\f\u0007"+
		"\f\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000"+
		"\u0001\u0000\u0001\u0000\u0001\u0001\u0005\u0001$\b\u0001\n\u0001\f\u0001"+
		"\'\t\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0003"+
		"\u0005\u0003.\b\u0003\n\u0003\f\u00031\t\u0003\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0003\u00047\b\u0004\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0007\u0001\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001"+
		"\b\u0001\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0005\tP\b"+
		"\t\n\t\f\tS\t\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0001\n\u0005"+
		"\n[\b\n\n\n\f\n^\t\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001"+
		"\u000b\u0001\u000b\u0001\u000b\u0003\u000bm\b\u000b\u0001\f\u0005\fp\b"+
		"\f\n\f\f\fs\t\f\u0001\f\u0000\u0000\r\u0000\u0002\u0004\u0006\b\n\f\u000e"+
		"\u0010\u0012\u0014\u0016\u0018\u0000\u0001\u0001\u0000\u0001$r\u0000\u001a"+
		"\u0001\u0000\u0000\u0000\u0002%\u0001\u0000\u0000\u0000\u0004(\u0001\u0000"+
		"\u0000\u0000\u0006/\u0001\u0000\u0000\u0000\b6\u0001\u0000\u0000\u0000"+
		"\n8\u0001\u0000\u0000\u0000\f<\u0001\u0000\u0000\u0000\u000e@\u0001\u0000"+
		"\u0000\u0000\u0010C\u0001\u0000\u0000\u0000\u0012I\u0001\u0000\u0000\u0000"+
		"\u0014T\u0001\u0000\u0000\u0000\u0016l\u0001\u0000\u0000\u0000\u0018q"+
		"\u0001\u0000\u0000\u0000\u001a\u001b\u0005\r\u0000\u0000\u001b\u001c\u0005"+
		"\u0002\u0000\u0000\u001c\u001d\u0006\u0000\uffff\uffff\u0000\u001d\u001e"+
		"\u0003\u0002\u0001\u0000\u001e\u001f\u0006\u0000\uffff\uffff\u0000\u001f"+
		" \u0003\u0006\u0003\u0000 !\u0005\u0005\u0000\u0000!\u0001\u0001\u0000"+
		"\u0000\u0000\"$\u0003\u0004\u0002\u0000#\"\u0001\u0000\u0000\u0000$\'"+
		"\u0001\u0000\u0000\u0000%#\u0001\u0000\u0000\u0000%&\u0001\u0000\u0000"+
		"\u0000&\u0003\u0001\u0000\u0000\u0000\'%\u0001\u0000\u0000\u0000()\u0005"+
		"\u0010\u0000\u0000)*\u0005\u0013\u0000\u0000*+\u0006\u0002\uffff\uffff"+
		"\u0000+\u0005\u0001\u0000\u0000\u0000,.\u0003\b\u0004\u0000-,\u0001\u0000"+
		"\u0000\u0000.1\u0001\u0000\u0000\u0000/-\u0001\u0000\u0000\u0000/0\u0001"+
		"\u0000\u0000\u00000\u0007\u0001\u0000\u0000\u00001/\u0001\u0000\u0000"+
		"\u000027\u0003\n\u0005\u000037\u0003\f\u0006\u000047\u0003\u000e\u0007"+
		"\u000057\u0003\u0010\b\u000062\u0001\u0000\u0000\u000063\u0001\u0000\u0000"+
		"\u000064\u0001\u0000\u0000\u000065\u0001\u0000\u0000\u00007\t\u0001\u0000"+
		"\u0000\u000089\u0005\u000e\u0000\u00009:\u0005\u0013\u0000\u0000:;\u0006"+
		"\u0005\uffff\uffff\u0000;\u000b\u0001\u0000\u0000\u0000<=\u0005\u0012"+
		"\u0000\u0000=>\u0003\u0012\t\u0000>?\u0006\u0006\uffff\uffff\u0000?\r"+
		"\u0001\u0000\u0000\u0000@A\u0005\b\u0000\u0000AB\u0006\u0007\uffff\uffff"+
		"\u0000B\u000f\u0001\u0000\u0000\u0000CD\u0005\n\u0000\u0000DE\u0005\u0013"+
		"\u0000\u0000EF\u0005\u001c\u0000\u0000FG\u0003\u0012\t\u0000GH\u0006\b"+
		"\uffff\uffff\u0000H\u0011\u0001\u0000\u0000\u0000IJ\u0003\u0014\n\u0000"+
		"JQ\u0006\t\uffff\uffff\u0000KL\u0005\u0017\u0000\u0000LM\u0003\u0014\n"+
		"\u0000MN\u0006\t\uffff\uffff\u0000NP\u0001\u0000\u0000\u0000OK\u0001\u0000"+
		"\u0000\u0000PS\u0001\u0000\u0000\u0000QO\u0001\u0000\u0000\u0000QR\u0001"+
		"\u0000\u0000\u0000R\u0013\u0001\u0000\u0000\u0000SQ\u0001\u0000\u0000"+
		"\u0000TU\u0003\u0016\u000b\u0000U\\\u0006\n\uffff\uffff\u0000VW\u0005"+
		"\u0019\u0000\u0000WX\u0003\u0016\u000b\u0000XY\u0006\n\uffff\uffff\u0000"+
		"Y[\u0001\u0000\u0000\u0000ZV\u0001\u0000\u0000\u0000[^\u0001\u0000\u0000"+
		"\u0000\\Z\u0001\u0000\u0000\u0000\\]\u0001\u0000\u0000\u0000]\u0015\u0001"+
		"\u0000\u0000\u0000^\\\u0001\u0000\u0000\u0000_`\u0005\u0013\u0000\u0000"+
		"`m\u0006\u000b\uffff\uffff\u0000ab\u0005\u0014\u0000\u0000bm\u0006\u000b"+
		"\uffff\uffff\u0000cd\u0005\u0018\u0000\u0000de\u0003\u0016\u000b\u0000"+
		"ef\u0006\u000b\uffff\uffff\u0000fm\u0001\u0000\u0000\u0000gh\u0005#\u0000"+
		"\u0000hi\u0003\u0012\t\u0000ij\u0005$\u0000\u0000jk\u0006\u000b\uffff"+
		"\uffff\u0000km\u0001\u0000\u0000\u0000l_\u0001\u0000\u0000\u0000la\u0001"+
		"\u0000\u0000\u0000lc\u0001\u0000\u0000\u0000lg\u0001\u0000\u0000\u0000"+
		"m\u0017\u0001\u0000\u0000\u0000np\u0007\u0000\u0000\u0000on\u0001\u0000"+
		"\u0000\u0000ps\u0001\u0000\u0000\u0000qo\u0001\u0000\u0000\u0000qr\u0001"+
		"\u0000\u0000\u0000r\u0019\u0001\u0000\u0000\u0000sq\u0001\u0000\u0000"+
		"\u0000\u0007%/6Q\\lq";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}