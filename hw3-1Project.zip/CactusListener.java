// Generated from Cactus.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CactusParser}.
 */
public interface CactusListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CactusParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(CactusParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link CactusParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(CactusParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link CactusParser#declarations}.
	 * @param ctx the parse tree
	 */
	void enterDeclarations(CactusParser.DeclarationsContext ctx);
	/**
	 * Exit a parse tree produced by {@link CactusParser#declarations}.
	 * @param ctx the parse tree
	 */
	void exitDeclarations(CactusParser.DeclarationsContext ctx);
	/**
	 * Enter a parse tree produced by {@link CactusParser#statements}.
	 * @param ctx the parse tree
	 */
	void enterStatements(CactusParser.StatementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link CactusParser#statements}.
	 * @param ctx the parse tree
	 */
	void exitStatements(CactusParser.StatementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link CactusParser#token}.
	 * @param ctx the parse tree
	 */
	void enterToken(CactusParser.TokenContext ctx);
	/**
	 * Exit a parse tree produced by {@link CactusParser#token}.
	 * @param ctx the parse tree
	 */
	void exitToken(CactusParser.TokenContext ctx);
}