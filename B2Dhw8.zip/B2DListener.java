// Generated from B2D.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link B2DParser}.
 */
public interface B2DListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link B2DParser#statements}.
	 * @param ctx the parse tree
	 */
	void enterStatements(B2DParser.StatementsContext ctx);
	/**
	 * Exit a parse tree produced by {@link B2DParser#statements}.
	 * @param ctx the parse tree
	 */
	void exitStatements(B2DParser.StatementsContext ctx);
	/**
	 * Enter a parse tree produced by {@link B2DParser#left}.
	 * @param ctx the parse tree
	 */
	void enterLeft(B2DParser.LeftContext ctx);
	/**
	 * Exit a parse tree produced by {@link B2DParser#left}.
	 * @param ctx the parse tree
	 */
	void exitLeft(B2DParser.LeftContext ctx);
	/**
	 * Enter a parse tree produced by {@link B2DParser#lefts}.
	 * @param ctx the parse tree
	 */
	void enterLefts(B2DParser.LeftsContext ctx);
	/**
	 * Exit a parse tree produced by {@link B2DParser#lefts}.
	 * @param ctx the parse tree
	 */
	void exitLefts(B2DParser.LeftsContext ctx);
	/**
	 * Enter a parse tree produced by {@link B2DParser#right}.
	 * @param ctx the parse tree
	 */
	void enterRight(B2DParser.RightContext ctx);
	/**
	 * Exit a parse tree produced by {@link B2DParser#right}.
	 * @param ctx the parse tree
	 */
	void exitRight(B2DParser.RightContext ctx);
	/**
	 * Enter a parse tree produced by {@link B2DParser#rights}.
	 * @param ctx the parse tree
	 */
	void enterRights(B2DParser.RightsContext ctx);
	/**
	 * Exit a parse tree produced by {@link B2DParser#rights}.
	 * @param ctx the parse tree
	 */
	void exitRights(B2DParser.RightsContext ctx);
	/**
	 * Enter a parse tree produced by {@link B2DParser#bool}.
	 * @param ctx the parse tree
	 */
	void enterBool(B2DParser.BoolContext ctx);
	/**
	 * Exit a parse tree produced by {@link B2DParser#bool}.
	 * @param ctx the parse tree
	 */
	void exitBool(B2DParser.BoolContext ctx);
}