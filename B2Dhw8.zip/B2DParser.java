// Generated from B2D.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class B2DParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		Point=1, Zero=2, One=3, WHITESPACE=4;
	public static final int
		RULE_statements = 0, RULE_left = 1, RULE_lefts = 2, RULE_right = 3, RULE_rights = 4, 
		RULE_bool = 5;
	private static String[] makeRuleNames() {
		return new String[] {
			"statements", "left", "lefts", "right", "rights", "bool"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'.'", "'0'", "'1'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "Point", "Zero", "One", "WHITESPACE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "B2D.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public B2DParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StatementsContext extends ParserRuleContext {
		public double val;
		public LeftContext l;
		public RightContext r;
		public TerminalNode Point() { return getToken(B2DParser.Point, 0); }
		public LeftContext left() {
			return getRuleContext(LeftContext.class,0);
		}
		public RightContext right() {
			return getRuleContext(RightContext.class,0);
		}
		public StatementsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statements; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).enterStatements(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).exitStatements(this);
		}
	}

	public final StatementsContext statements() throws RecognitionException {
		StatementsContext _localctx = new StatementsContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_statements);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(12);
			((StatementsContext)_localctx).l = left();
			setState(13);
			match(Point);
			setState(14);
			((StatementsContext)_localctx).r = right();

			            ((StatementsContext)_localctx).val =  ((StatementsContext)_localctx).l.val + ((StatementsContext)_localctx).r.val;
			            System.out.println("Test input : " + (((StatementsContext)_localctx).l!=null?_input.getText(((StatementsContext)_localctx).l.start,((StatementsContext)_localctx).l.stop):null) + "." + (((StatementsContext)_localctx).r!=null?_input.getText(((StatementsContext)_localctx).r.start,((StatementsContext)_localctx).r.stop):null));
			            System.out.println("Expected output : " + _localctx.val);
			        
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LeftContext extends ParserRuleContext {
		public double val;
		public BoolContext b;
		public LeftsContext ls;
		public BoolContext bool() {
			return getRuleContext(BoolContext.class,0);
		}
		public LeftsContext lefts() {
			return getRuleContext(LeftsContext.class,0);
		}
		public LeftContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_left; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).enterLeft(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).exitLeft(this);
		}
	}

	public final LeftContext left() throws RecognitionException {
		LeftContext _localctx = new LeftContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_left);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(17);
			((LeftContext)_localctx).b = bool();
			setState(18);
			((LeftContext)_localctx).ls = lefts();
			((LeftContext)_localctx).val =  ((LeftContext)_localctx).b.val * (1 << ((LeftContext)_localctx).ls.len) + ((LeftContext)_localctx).ls.val;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LeftsContext extends ParserRuleContext {
		public double val;
		public int len;
		public BoolContext b;
		public LeftsContext ls;
		public BoolContext bool() {
			return getRuleContext(BoolContext.class,0);
		}
		public LeftsContext lefts() {
			return getRuleContext(LeftsContext.class,0);
		}
		public LeftsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lefts; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).enterLefts(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).exitLefts(this);
		}
	}

	public final LeftsContext lefts() throws RecognitionException {
		LeftsContext _localctx = new LeftsContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_lefts);
		try {
			setState(26);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Zero:
			case One:
				enterOuterAlt(_localctx, 1);
				{
				setState(21);
				((LeftsContext)_localctx).b = bool();
				setState(22);
				((LeftsContext)_localctx).ls = lefts();

				        ((LeftsContext)_localctx).len =  ((LeftsContext)_localctx).ls.len + 1;
				        ((LeftsContext)_localctx).val =  ((LeftsContext)_localctx).b.val * (1 << ((LeftsContext)_localctx).ls.len) + ((LeftsContext)_localctx).ls.val;
				    
				}
				break;
			case Point:
				enterOuterAlt(_localctx, 2);
				{
				((LeftsContext)_localctx).len =  0; ((LeftsContext)_localctx).val =  0;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RightContext extends ParserRuleContext {
		public double val;
		public BoolContext b;
		public RightsContext rs;
		public BoolContext bool() {
			return getRuleContext(BoolContext.class,0);
		}
		public RightsContext rights() {
			return getRuleContext(RightsContext.class,0);
		}
		public RightContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_right; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).enterRight(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).exitRight(this);
		}
	}

	public final RightContext right() throws RecognitionException {
		RightContext _localctx = new RightContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_right);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(28);
			((RightContext)_localctx).b = bool();
			setState(29);
			((RightContext)_localctx).rs = rights();
			((RightContext)_localctx).val =  (((RightContext)_localctx).b.val + ((RightContext)_localctx).rs.val) / 2.0;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RightsContext extends ParserRuleContext {
		public double val;
		public BoolContext b;
		public RightsContext rs;
		public BoolContext bool() {
			return getRuleContext(BoolContext.class,0);
		}
		public RightsContext rights() {
			return getRuleContext(RightsContext.class,0);
		}
		public RightsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rights; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).enterRights(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).exitRights(this);
		}
	}

	public final RightsContext rights() throws RecognitionException {
		RightsContext _localctx = new RightsContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_rights);
		try {
			setState(37);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Zero:
			case One:
				enterOuterAlt(_localctx, 1);
				{
				setState(32);
				((RightsContext)_localctx).b = bool();
				setState(33);
				((RightsContext)_localctx).rs = rights();

				      ((RightsContext)_localctx).val =  (((RightsContext)_localctx).b.val + ((RightsContext)_localctx).rs.val) / 2;
				    
				}
				break;
			case EOF:
				enterOuterAlt(_localctx, 2);
				{
				((RightsContext)_localctx).val =  0.0;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BoolContext extends ParserRuleContext {
		public double val;
		public TerminalNode Zero() { return getToken(B2DParser.Zero, 0); }
		public TerminalNode One() { return getToken(B2DParser.One, 0); }
		public BoolContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bool; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).enterBool(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof B2DListener ) ((B2DListener)listener).exitBool(this);
		}
	}

	public final BoolContext bool() throws RecognitionException {
		BoolContext _localctx = new BoolContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_bool);
		try {
			setState(43);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Zero:
				enterOuterAlt(_localctx, 1);
				{
				setState(39);
				match(Zero);
				 ((BoolContext)_localctx).val =  0;
				}
				break;
			case One:
				enterOuterAlt(_localctx, 2);
				{
				setState(41);
				match(One);
				 ((BoolContext)_localctx).val =  1;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0004.\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001"+
		"\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0003\u0002\u001b\b\u0002\u0001"+
		"\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0004\u0001\u0004\u0001"+
		"\u0004\u0001\u0004\u0001\u0004\u0003\u0004&\b\u0004\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0003\u0005,\b\u0005\u0001\u0005\u0000"+
		"\u0000\u0006\u0000\u0002\u0004\u0006\b\n\u0000\u0000*\u0000\f\u0001\u0000"+
		"\u0000\u0000\u0002\u0011\u0001\u0000\u0000\u0000\u0004\u001a\u0001\u0000"+
		"\u0000\u0000\u0006\u001c\u0001\u0000\u0000\u0000\b%\u0001\u0000\u0000"+
		"\u0000\n+\u0001\u0000\u0000\u0000\f\r\u0003\u0002\u0001\u0000\r\u000e"+
		"\u0005\u0001\u0000\u0000\u000e\u000f\u0003\u0006\u0003\u0000\u000f\u0010"+
		"\u0006\u0000\uffff\uffff\u0000\u0010\u0001\u0001\u0000\u0000\u0000\u0011"+
		"\u0012\u0003\n\u0005\u0000\u0012\u0013\u0003\u0004\u0002\u0000\u0013\u0014"+
		"\u0006\u0001\uffff\uffff\u0000\u0014\u0003\u0001\u0000\u0000\u0000\u0015"+
		"\u0016\u0003\n\u0005\u0000\u0016\u0017\u0003\u0004\u0002\u0000\u0017\u0018"+
		"\u0006\u0002\uffff\uffff\u0000\u0018\u001b\u0001\u0000\u0000\u0000\u0019"+
		"\u001b\u0006\u0002\uffff\uffff\u0000\u001a\u0015\u0001\u0000\u0000\u0000"+
		"\u001a\u0019\u0001\u0000\u0000\u0000\u001b\u0005\u0001\u0000\u0000\u0000"+
		"\u001c\u001d\u0003\n\u0005\u0000\u001d\u001e\u0003\b\u0004\u0000\u001e"+
		"\u001f\u0006\u0003\uffff\uffff\u0000\u001f\u0007\u0001\u0000\u0000\u0000"+
		" !\u0003\n\u0005\u0000!\"\u0003\b\u0004\u0000\"#\u0006\u0004\uffff\uffff"+
		"\u0000#&\u0001\u0000\u0000\u0000$&\u0006\u0004\uffff\uffff\u0000% \u0001"+
		"\u0000\u0000\u0000%$\u0001\u0000\u0000\u0000&\t\u0001\u0000\u0000\u0000"+
		"\'(\u0005\u0002\u0000\u0000(,\u0006\u0005\uffff\uffff\u0000)*\u0005\u0003"+
		"\u0000\u0000*,\u0006\u0005\uffff\uffff\u0000+\'\u0001\u0000\u0000\u0000"+
		"+)\u0001\u0000\u0000\u0000,\u000b\u0001\u0000\u0000\u0000\u0003\u001a"+
		"%+";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}