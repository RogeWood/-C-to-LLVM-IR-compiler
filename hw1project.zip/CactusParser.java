// Generated from Cactus.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class CactusParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		And=1, Begin=2, Do=3, Else=4, End=5, EndIf=6, EndWhile=7, Exit=8, If=9, 
		Set=10, Not=11, Or=12, Program=13, Read=14, Then=15, Var=16, While=17, 
		Write=18, ID=19, CONST=20, ADD=21, SUB=22, MUL=23, DIV=24, MOD=25, ASSIGN=26, 
		EQUAL=27, NOTEQUAL=28, GREATER=29, GREATEREQUAL=30, LESS=31, LESSEQUAL=32, 
		LPAREN=33, RPAREN=34, WHITESPACE=35, COMMENT=36;
	public static final int
		RULE_token = 0;
	private static String[] makeRuleNames() {
		return new String[] {
			"token"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'And'", "'Begin'", "'Do'", "'Else'", "'End'", "'EndIf'", "'EndWhile'", 
			"'Exit'", "'If'", "'Set'", "'Not'", "'Or'", "'Program'", "'Read'", "'Then'", 
			"'Var'", "'While'", "'Write'", null, null, "'+'", "'-'", "'*'", "'/'", 
			"'%'", "'='", "'=='", "'<>'", "'>'", "'>='", "'<'", "'<='", "'('", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "And", "Begin", "Do", "Else", "End", "EndIf", "EndWhile", "Exit", 
			"If", "Set", "Not", "Or", "Program", "Read", "Then", "Var", "While", 
			"Write", "ID", "CONST", "ADD", "SUB", "MUL", "DIV", "MOD", "ASSIGN", 
			"EQUAL", "NOTEQUAL", "GREATER", "GREATEREQUAL", "LESS", "LESSEQUAL", 
			"LPAREN", "RPAREN", "WHITESPACE", "COMMENT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Cactus.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public CactusParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TokenContext extends ParserRuleContext {
		public TerminalNode And() { return getToken(CactusParser.And, 0); }
		public TerminalNode Begin() { return getToken(CactusParser.Begin, 0); }
		public TerminalNode Do() { return getToken(CactusParser.Do, 0); }
		public TerminalNode Else() { return getToken(CactusParser.Else, 0); }
		public TerminalNode End() { return getToken(CactusParser.End, 0); }
		public TerminalNode EndIf() { return getToken(CactusParser.EndIf, 0); }
		public TerminalNode EndWhile() { return getToken(CactusParser.EndWhile, 0); }
		public TerminalNode Exit() { return getToken(CactusParser.Exit, 0); }
		public TerminalNode If() { return getToken(CactusParser.If, 0); }
		public TerminalNode Set() { return getToken(CactusParser.Set, 0); }
		public TerminalNode Not() { return getToken(CactusParser.Not, 0); }
		public TerminalNode Or() { return getToken(CactusParser.Or, 0); }
		public TerminalNode Program() { return getToken(CactusParser.Program, 0); }
		public TerminalNode Read() { return getToken(CactusParser.Read, 0); }
		public TerminalNode Then() { return getToken(CactusParser.Then, 0); }
		public TerminalNode Var() { return getToken(CactusParser.Var, 0); }
		public TerminalNode While() { return getToken(CactusParser.While, 0); }
		public TerminalNode Write() { return getToken(CactusParser.Write, 0); }
		public TerminalNode ID() { return getToken(CactusParser.ID, 0); }
		public TerminalNode CONST() { return getToken(CactusParser.CONST, 0); }
		public TerminalNode ADD() { return getToken(CactusParser.ADD, 0); }
		public TerminalNode SUB() { return getToken(CactusParser.SUB, 0); }
		public TerminalNode MUL() { return getToken(CactusParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(CactusParser.DIV, 0); }
		public TerminalNode MOD() { return getToken(CactusParser.MOD, 0); }
		public TerminalNode ASSIGN() { return getToken(CactusParser.ASSIGN, 0); }
		public TerminalNode EQUAL() { return getToken(CactusParser.EQUAL, 0); }
		public TerminalNode NOTEQUAL() { return getToken(CactusParser.NOTEQUAL, 0); }
		public TerminalNode GREATER() { return getToken(CactusParser.GREATER, 0); }
		public TerminalNode GREATEREQUAL() { return getToken(CactusParser.GREATEREQUAL, 0); }
		public TerminalNode LESS() { return getToken(CactusParser.LESS, 0); }
		public TerminalNode LESSEQUAL() { return getToken(CactusParser.LESSEQUAL, 0); }
		public TerminalNode LPAREN() { return getToken(CactusParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(CactusParser.RPAREN, 0); }
		public TerminalNode WHITESPACE() { return getToken(CactusParser.WHITESPACE, 0); }
		public TerminalNode COMMENT() { return getToken(CactusParser.COMMENT, 0); }
		public TokenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_token; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).enterToken(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof CactusListener ) ((CactusListener)listener).exitToken(this);
		}
	}

	public final TokenContext token() throws RecognitionException {
		TokenContext _localctx = new TokenContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_token);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(2);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 137438953470L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001$\u0005\u0002\u0000\u0007\u0000\u0001\u0000\u0001\u0000\u0001"+
		"\u0000\u0000\u0000\u0001\u0000\u0000\u0001\u0001\u0000\u0001$\u0003\u0000"+
		"\u0002\u0001\u0000\u0000\u0000\u0002\u0003\u0007\u0000\u0000\u0000\u0003"+
		"\u0001\u0001\u0000\u0000\u0000\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}